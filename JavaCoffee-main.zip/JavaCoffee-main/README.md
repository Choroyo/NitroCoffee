JavaCoffee
Developed by Innovative Minds Team

Team Members

Oscar Mallen
Yael Reyes


Project Description
JavaCoffee is a mobile application designed for coffee enthusiasts. It serves as a comprehensive platform where users can explore a wide range of coffee recipes, create and manage their own recipes, and access a marketplace for coffee-related products.

Key Features

Recipe Exploration: Users can browse and view detailed coffee recipes, complete with instructions and ingredients.
Personal Recipe Creation: Allows users to add their own recipes to the app for personal use or to share with others.
Marketplace Integration: A section for discovering and purchasing coffee beans, brewing equipment, and accessories, with direct links to vendors’ sites.
Profile Management: Users can view their profiles, manage their recipes, and log out.

Steps to Run the Project


Clone the Repository:
Clone the JavaCoffee repository to your local machine using git clone feature.

Project Setup:
Open the project in Android Studio or your preferred IDE.
Ensure all dependencies are properly installed as listed in the build.gradle file.

Run the Application:
Start the app on an emulator or physical device from within Android Studio.

Navigate the App:
Login/Register: Sign up or log in to access personalized features.
Recipes Page: Default landing page where you can select and view recipes.
Add Recipes: Click the 'Add Recipe' button to contribute new recipes.
Marketplace: Use the bottom navigation to visit the marketplace.
Profile Page: Manage your profile and log out through the bottom navigation.