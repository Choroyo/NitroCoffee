package edu.utsa.cs3443.nitrocoffe.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.HashMap;

import edu.utsa.cs3443.nitrocoffe.R;

/**
 * Recipes is a class that represents a recipe with various attributes such as name, coffeeGrams, waterGrams, milkGrams, otherIngredients, recipeImageResId, and recipeDescription.
 * It provides getter and setter methods for each attribute.
 *
 * @author Yael Reyes
 * @author Oscar Mallen
 * @author Bryan Chora
 * @author Boston Jones
 */
@Keep
public class Recipes implements Parcelable {
    private String recipeName;
    private String waterGrams;
    private String coffeeGrams;
    private String milkGrams;
    private ArrayList<String> otherIngredients;
    private int recipeImageResId;
    private String recipeDescription;

    /**
     * Constructor for Recipes.
     *
     * @param recipeName the name of the recipe.
     * @param coffeeGrams the amount of coffee in grams.
     * @param waterGrams the amount of water in grams.
     * @param milkGrams the amount of milk in grams.
     * @param otherIngredients the list of other ingredients.
     * @param recipeImageResId the resource ID of the recipe image.
     * @param recipeDescription the description of the recipe.
     */
    public Recipes(String recipeName, String coffeeGrams, String waterGrams, String milkGrams,ArrayList<String> otherIngredients, int recipeImageResId, String recipeDescription) {
        this.recipeName = recipeName;
        this.coffeeGrams = coffeeGrams;
        this.waterGrams = waterGrams;
        this.milkGrams = milkGrams;
        this.otherIngredients = otherIngredients;
        this.recipeImageResId = recipeImageResId;
        this.recipeDescription = recipeDescription;
    }

    /**
     * Constructor for Recipes.
     *
     * @param recipeName the name of the recipe.
     * @param coffeeGrams the amount of coffee in grams.
     * @param waterGrams the amount of water in grams.
     * @param milkGrams the amount of milk in grams.
     * @param otherIngredients the list of other ingredients.
     * @param recipeDescription the description of the recipe.
     */
    public Recipes(String recipeName, String coffeeGrams, String waterGrams, String milkGrams,ArrayList<String> otherIngredients, String recipeDescription) {
        this.recipeName = recipeName;
        this.coffeeGrams = coffeeGrams;
        this.waterGrams = waterGrams;
        this.milkGrams = milkGrams;
        this.otherIngredients = otherIngredients;
        this.recipeDescription = recipeDescription;
    }

    /**
     * Constructor for Recipes that creates a new instance from a Parcel.
     *
     * @param in the Parcel to read the object's data from.
     */
    protected Recipes(Parcel in) {
        recipeName = in.readString();
        waterGrams = in.readString();
        coffeeGrams = in.readString();
        milkGrams = in.readString();
        otherIngredients = in.createStringArrayList();
        recipeImageResId = in.readInt();
        recipeDescription = in.readString();
    }

    /**
     * A public CREATOR field that generates instances of your Parcelable class from a Parcel.
     */
    public static final Creator<Recipes> CREATOR = new Creator<Recipes>() {
        @Override
        public Recipes createFromParcel(Parcel in) {
            return new Recipes(in);
        }

        @Override
        public Recipes[] newArray(int size) {
            return new Recipes[size];
        }
    };

    /**
     * Gets the name of the recipe.
     *
     * @return the name of the recipe.
     */
    public String getRecipeName() {
        return recipeName;
    }

    /**
     * Sets the name of the recipe.
     *
     * @param recipeName the new name of the recipe.
     */
    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    /**
     * Gets the description of the recipe.
     *
     * @return the description of the recipe.
     */
    public String getRecipeDescription() {
        return recipeDescription;
    }

    /**
     * Sets the description of the recipe.
     *
     * @param recipeDescription the new description of the recipe.
     */
    public void setRecipeDescription(String recipeDescription) {
        this.recipeDescription = recipeDescription;
    }

    /**
     * Gets the amount of coffee in grams.
     *
     * @return the amount of coffee in grams.
     */
    public String getCoffeeGrams() {
        return coffeeGrams;
    }

    /**
     * Sets the amount of coffee in grams.
     *
     * @param coffeeGrams the new amount of coffee in grams.
     */
    public void setCoffeeGrams(String coffeeGrams) {
        this.coffeeGrams = coffeeGrams;
    }

    /**
     * Gets the amount of water in grams.
     *
     * @return the amount of water in grams.
     */
    public String getWaterGrams() {
        return waterGrams;
    }

    /**
     * Sets the amount of water in grams.
     *
     * @param waterGrams the new amount of water in grams.
     */
    public void setWaterGrams(String waterGrams) {
        this.waterGrams = waterGrams;
    }

    /**
     * Gets the amount of milk in grams.
     *
     * @return the amount of milk in grams.
     */
    public String getMilkGrams() {
        return milkGrams;
    }

    /**
     * Sets the amount of milk in grams.
     *
     * @param milkGrams the new amount of milk in grams.
     */
    public void setMilkGrams(String milkGrams) {
        this.milkGrams = milkGrams;
    }

    /**
     * Gets the list of other ingredients.
     *
     * @return the list of other ingredients.
     */
    public ArrayList<String> getOtherIngredients() {
        return otherIngredients;
    }

    /**
     * Sets the list of other ingredients.
     *
     * @param otherIngredients the new list of other ingredients.
     */
    public void setOtherIngredients(ArrayList<String> otherIngredients) {
        this.otherIngredients = otherIngredients;
    }

    /**
     * Gets the resource ID of the recipe image.
     *
     * @return the resource ID of the recipe image.
     */
    public int getRecipeImageResId() {
        return recipeImageResId;
    }

    /**
     * Sets the resource ID of the recipe image.
     *
     * @param recipeImageResId the new resource ID of the recipe image.
     */
    public void setRecipeImageResId(int recipeImageResId) {
        this.recipeImageResId = recipeImageResId;
    }

    /**
     * Describes the kinds of special objects contained in this Parcelable's
     * marshalled representation.
     *
     * @return a bitmask indicating the set of special object types marshalled
     * by the Parcelable.
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * Writes the object's data to the given Parcel.
     *
     * @param dest the Parcel to write the object's data to.
     * @param flags additional flags about how the object should be written.
     */
    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(recipeName);
        dest.writeString(waterGrams);
        dest.writeString(coffeeGrams);
        dest.writeString(milkGrams);
        dest.writeStringList(otherIngredients);
        dest.writeInt(recipeImageResId);
        dest.writeString(recipeDescription);
    }

    /**
     * Returns a string representation of the object.
     *
     * @return a string representation of the object.
     */
    @NonNull
    @Override
    public String toString() {
        return "Recipes{" +
                "recipeName='" + recipeName + '\'' +
                ", waterGrams='" + waterGrams + '\'' +
                ", coffeeGrams='" + coffeeGrams + '\'' +
                ", milkGrams='" + milkGrams + '\'' +
                ", otherIngredients=" + otherIngredients +
                ", recipeImageResId=" + recipeImageResId +
                ", recipeDescription='" + recipeDescription + '\'' +
                '}';
    }

    /**
     * Returns a HashMap of recipe names and their corresponding image resource IDs.
     *
     * @return a HashMap of recipe names and their corresponding image resource IDs.
     */
    public static HashMap<String, Integer> getRecipeImages() {
        HashMap<String, Integer> recipeImages = new HashMap<>();

        recipeImages.put("cappuccino", R.drawable.capuchino);
        recipeImages.put("espresso", R.drawable.espresso);
        recipeImages.put("latte", R.drawable.breve);
        recipeImages.put("americano", R.drawable.americano);
        recipeImages.put("mocha", R.drawable.mocha);
        recipeImages.put("macchiato", R.drawable.macchiato);
        recipeImages.put("cortado", R.drawable.cortado);
        recipeImages.put("flat white", R.drawable.flat_white);
        recipeImages.put("affogato", R.drawable.affogato);
        recipeImages.put("irish coffee", R.drawable.irish_coffee);
        recipeImages.put("turkish coffee", R.drawable.turkish_coffee);
        recipeImages.put("vienna coffee", R.drawable.vienna_coffee);
        recipeImages.put("cuban coffee", R.drawable.cuban_coffee);

        return recipeImages;
    }
}