package edu.utsa.cs3443.nitrocoffe;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * MarketplaceFragment is a subclass of Fragment.
 * It represents a marketplace where items are displayed in a RecyclerView.
 *
 * @author Yael Reyes
 * @author Oscar Mallen
 */
public class MarketplaceFragment extends Fragment {
    private RecyclerView recyclerView;
    private MarketplaceAdapter adapter;
    private ArrayList<MarketplaceItem> marketplaceItems;

    /**
     * ViewHolder is a static inner class inside MarketplaceFragment.
     * It holds the views that will be used to display a single item in the RecyclerView.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        ImageView imageView;

        /**
         * Constructor for ViewHolder.
         *
         * @param itemView The View that you inflate in onCreateViewHolder().
         */
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.itemName);
            imageView = itemView.findViewById(R.id.itemImage);
        }
    }

    /**
     * Called to have the fragment instantiate its user interface view.
     *
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_marketplace, container, false);

        recyclerView = view.findViewById(R.id.marketplaceRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2)); // 2 columns for square items

        // Initialize the ArrayList
        marketplaceItems = new ArrayList<>();

        // Load the items from the CSV file
        loadMarketplaceItems();

        // Set the adapter
        adapter = new MarketplaceAdapter(getContext(), marketplaceItems);
        recyclerView.setAdapter(adapter);

        return view;
    }

    /**
     * Loads the marketplace items from a CSV file.
     */
    private void loadMarketplaceItems() {
        try {
            InputStream inputStream = getContext().getAssets().open("MarketplaceItems.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    String name = parts[1];
                    String price = parts[2];
                    String imageName = parts[3];
                    String hyperlink = parts[4];
                    marketplaceItems.add(new MarketplaceItem(name, price, imageName, hyperlink));
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}