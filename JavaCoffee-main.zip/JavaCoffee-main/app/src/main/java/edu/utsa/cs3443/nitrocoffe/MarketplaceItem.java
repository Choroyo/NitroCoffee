package edu.utsa.cs3443.nitrocoffe;

/**
 * MarketplaceItem is a class that represents an item in the marketplace.
 * It has a name, price, image name, and a hyperlink.
 *
 * @author Yael Reyes
 * @author Oscar Mallen
 */
public class MarketplaceItem {
    private String name;
    private String price;
    private String imageName;
    private String hyperlink;

    /**
     * Constructor for MarketplaceItem.
     *
     * @param name the name of the item.
     * @param price the price of the item.
     * @param imageName the name of the image of the item.
     * @param hyperlink the hyperlink of the item.
     */
    public MarketplaceItem(String name, String price, String imageName, String hyperlink) {
        this.name = name;
        this.price = price;
        this.imageName = imageName;
        this.hyperlink = hyperlink;
    }

    /**
     * Gets the name of the item.
     *
     * @return the name of the item.
     */
    public String getName() { return name; }

    /**
     * Gets the price of the item.
     *
     * @return the price of the item.
     */
    public String getPrice() { return price; }

    /**
     * Gets the image name of the item.
     *
     * @return the image name of the item.
     */
    public String getImageName() { return imageName; }

    /**
     * Gets the hyperlink of the item.
     *
     * @return the hyperlink of the item.
     */
    public String getHyperlink() { return hyperlink; }
}