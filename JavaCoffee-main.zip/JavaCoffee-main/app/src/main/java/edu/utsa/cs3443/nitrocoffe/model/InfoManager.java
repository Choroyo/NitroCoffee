package edu.utsa.cs3443.nitrocoffe.model;
//
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import android.util.Log;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * InfoManager is a class that manages the information of users, posts, and recipes.
 * It provides methods to load and update data from files, and to validate user login.
 * It also provides methods to serialize and deserialize images for storage.
 *
 * @author Yael Reyes
 * @author Oscar Mallen
 *
 */
public class InfoManager {

    private static final String USER_FILE = "users.csv";
    private static final String RECIPE_FILE = "recipesinDevice.csv";
    private static final String POST_FILE = "post.csv";
    private Context context;
    private static ArrayList<User> users;

    /**
     * Constructor for InfoManager.
     *
     * @param context the context in which the InfoManager is being used.
     */
    public  InfoManager(Context context){
        this.context = context;
    }

    /**
     * Updates the user information in the file.
     *
     * @param context the context in which the method is being used.
     * @param updatedUser the user with updated information.
     * @param userList the list of users.
     * @throws IOException if an input or output exception occurred.
     */
    public static void updateUserInFile(Context context, User updatedUser, ArrayList<User> userList) throws IOException {
        for (User user : userList) {
            if (user.getUsername().equals(updatedUser.getUsername())) {
                user.setBio(updatedUser.getBio());
                break;
            }
        }
        FileOutputStream fos = context.openFileOutput(USER_FILE, Context.MODE_PRIVATE);
        OutputStreamWriter writer = new OutputStreamWriter(fos);
        for (User user : userList) {
            writer.append(user.getUsername()).append(",")
                    .append(user.getPassword()).append(",")
                    .append(user.getRealName()).append(",")
                    .append(user.getBio()).append(",")
                    .append(user.getPicture()).append("\n");
        }
        writer.close();
    }

    public static void updateUserInFilePicture(Context context, User updatedUser, ArrayList<User> userList,String picture) throws IOException {
        for (User user : userList) {
            if (user.getUsername().equals(updatedUser.getUsername())) {
                user.setPicture(picture);
                break;
            }
        }
        FileOutputStream fos = context.openFileOutput(USER_FILE, Context.MODE_PRIVATE);
        OutputStreamWriter writer = new OutputStreamWriter(fos);
        for (User user : userList) {
            writer.append(user.getUsername()).append(",")
                    .append(user.getPassword()).append(",")
                    .append(user.getRealName()).append(",")
                    .append(user.getBio()).append(",")
                    .append(user.getPicture()).append("\n");
        }
        writer.close();
    }

    /**
     * Initializes the user file.
     *
     * @param context the context in which the method is being used.
     * @throws IOException if an input or output exception occurred.
     */
    public static void initFileUser(Context context) throws IOException {
        File file = new File(context.getFilesDir(), USER_FILE);
        AssetManager manager = context.getAssets();
        InputStream files;
        if (!file.exists()) {
            files = manager.open("userInDevice.csv");
            InputStreamReader isr = new InputStreamReader(files);
            BufferedReader br = new BufferedReader(isr);
            String line;
            FileOutputStream out = context.openFileOutput(USER_FILE, Context.MODE_PRIVATE);
            while ((line = br.readLine()) != null){
                out.write((line + "\n").getBytes());
            }
            br.close();
            isr.close();
            out.close();
        }
    }

    /**
     * Initializes the post file.
     *
     * @param context the context in which the method is being used.
     * @throws IOException if an input or output exception occurred.
     */
    public static void initFilePost(Context context) throws IOException {
        File file = new File(context.getFilesDir(), POST_FILE);
        AssetManager manager = context.getAssets();
        InputStream files;
        if (!file.exists()) {
            files = manager.open("postInDevice.csv");
            InputStreamReader isr = new InputStreamReader(files);
            BufferedReader br = new BufferedReader(isr);
            String line;
            FileOutputStream out = context.openFileOutput(POST_FILE, Context.MODE_PRIVATE);
            while ((line = br.readLine()) != null){
                out.write((line + "\n").getBytes());
            }
            br.close();
            isr.close();
            out.close();
        }
    }

    /**
     * Loads the social data from the file.
     *
     * @param context the context in which the method is being used.
     * @return a list of social data.
     * @throws IOException if an input or output exception occurred.
     */


    /**
     * Loads the user data from the file.
     *
     * @param context the context in which the method is being used.
     * @return a list of users.
     * @throws IOException if an input or output exception occurred.
     */
    public static ArrayList<User> loadUsers(Context context) throws IOException {
        ArrayList<User> userList = new ArrayList<>();
        FileInputStream fis = context.openFileInput(USER_FILE);
        InputStreamReader reader = new InputStreamReader(fis);
        BufferedReader bufferedReader = new BufferedReader(reader);
        String line;
        int tokenCount = 0;
        while ((line = bufferedReader.readLine()) != null) {
            if (line.trim().isEmpty() && tokenCount >= 4) {
                break; // Stop reading if encountering a blank line after the 4th token
            }
            String[] parts = line.split(",");
            if (parts.length >= 4) { // Expecting at least 4 parts
                String username = parts[0];
                String password = parts[1];
                String realName = parts[2];
                String bio = parts[3]; // Added bio
                String picture = (parts.length > 4) ? parts[4] : "null"; // Handle optional picture field
                User user = new User(username, password, realName, bio, picture); // Passing 4 or 5 parameters based on parts availability
                userList.add(user);
                tokenCount++;
            }
        }
        bufferedReader.close();
        return userList;
    }
    /**
     * Loads the recipe data from the file.
     *
     * @param context the context in which the method is being used.
     * @return a list of recipes.
     * @throws IOException if an input or output exception occurred.
     */
    public static ArrayList<Recipes> loadRecipes(Context context) throws IOException {
        ArrayList<Recipes> recipeList = new ArrayList<>();
        FileInputStream fis = context.openFileInput(RECIPE_FILE);
        InputStreamReader reader = new InputStreamReader(fis);
        BufferedReader bufferedReader = new BufferedReader(reader);
        String line;
        bufferedReader.readLine();
        while ((line = bufferedReader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length >= 6) {
                String recipeName = parts[0];

                Log.i("InfoManager", "Recipe: " + recipeName);

                int recipeImage = Recipes.getRecipeImages().get(recipeName);
                String coffeeGrams = parts[1];
                String waterGrams = parts[2];
                String milkGrams = parts[3];
                ArrayList<String> otherIngredients = new ArrayList<>(Arrays.asList(parts[4].split(" "))); // Convert otherIngredients to ArrayList<String>

                StringBuilder recipeDescription = new StringBuilder(); // Initialize recipeDescription as an empty string
                for (int i = 5; i < parts.length; i++) {
                    recipeDescription.append(parts[i]);
                }
                Recipes recipe = new Recipes(recipeName, coffeeGrams, waterGrams,milkGrams, otherIngredients, recipeImage, recipeDescription.toString());
                recipeList.add(recipe);
            }
        }
        bufferedReader.close();
        return recipeList;
    }

    /**
     * Initializes the recipe file.
     *
     * @param context the context in which the method is being used.
     * @throws IOException if an input or output exception occurred.
     */
    public  static void initFileRecipes(Context context) throws IOException {
        File file = new File(context.getFilesDir(), RECIPE_FILE);
        AssetManager manager = context.getAssets();
        InputStream files;
        if (!file.exists()) {
            files = manager.open("recipesInDevice.csv");
            InputStreamReader isr = new InputStreamReader(files);
            BufferedReader br = new BufferedReader(isr);
            String line;
            FileOutputStream out = context.openFileOutput(RECIPE_FILE, Context.MODE_PRIVATE);
            while ((line = br.readLine()) != null){
                out.write((line + "\n").getBytes());
            }
            br.close();
            isr.close();
            out.close();
        }
    }

    /**
     * Adds a new user to the file.
     *
     * @param context the context in which the method is being used.
     * @param newUser the new user to be added.
     * @throws IOException if an input or output exception occurred.
     */
    public static void addUserInFile(Context context, User newUser) throws IOException {

        FileOutputStream fos = context.openFileOutput(USER_FILE, Context.MODE_APPEND);
        OutputStreamWriter writer = new OutputStreamWriter(fos);
        writer.append(newUser.getUsername()).append(",").append(newUser.getPassword()).append(",")
                .append(newUser.getRealName()).append(",Bio").append(",null").append("\n");
        writer.close();
    }

    /**
     * Finds a user by username.
     *
     * @param userList the list of users.
     * @param username the username of the user to be found.
     * @return the user if found, null otherwise.
     */
    public User findUserByUsername(ArrayList<User> userList, String username) {
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    /**
     * Adds a new recipe to the file.
     *
     * @param context the context in which the method is being used.
     * @param newRecipe the new recipe to be added.
     * @throws IOException if an input or output exception occurred.
     */
    public static void addRecipeToFile(Context context, Recipes newRecipe) throws IOException {
        FileOutputStream fos = context.openFileOutput(RECIPE_FILE, Context.MODE_APPEND);
        OutputStreamWriter writer = new OutputStreamWriter(fos);
        writer.append(newRecipe.getRecipeName()).append(",")
                .append(newRecipe.getCoffeeGrams()).append(",")
                .append(newRecipe.getWaterGrams()).append(",")
                .append(newRecipe.getMilkGrams()).append(",")
                .append(listToString(newRecipe.getOtherIngredients())).append(",")
                .append(newRecipe.getRecipeDescription()).append("\n");
        writer.close();
    }

    /**
     * Converts a list to a string.
     *
     * @param list the list to be converted.
     * @return the string representation of the list.
     */
    private static String listToString(ArrayList<String> list) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String item : list) {
            stringBuilder.append(item).append(";");
        }
        return stringBuilder.toString();
    }


    /**
     * Checks if a login is valid.
     *
     * @param name the username.
     * @param password the password.
     * @param userList the list of users.
     * @return true if the login is valid, false otherwise.
     */
    public boolean isValidLogin(String name, String password, ArrayList<User> userList) {
        for (User user : userList) {
            if (user.getUsername().equals(name) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Serializes a drawable to a string.
     *
     * @param context the context in which the method is being used.
     * @param drawable the drawable to be serialized.
     * @return the string representation of the drawable.
     */
    public static String serializeDrawable(Context context, Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] bitmapData = stream.toByteArray();
            return Base64.encodeToString(bitmapData, Base64.DEFAULT);
        }
        return null;
    }

    /**
     * Deserializes a string to a drawable.
     *
     * @param context the context in which the method is being used.
     * @param base64String the string to be deserialized.
     * @return the drawable representation of the string.
     */
    // Deserialize a Base64 encoded string to a Drawable
    public static Drawable deserializeDrawable(Context context, String base64String) {
        byte[] decodedString = Base64.decode(base64String, Base64.DEFAULT);
        Bitmap bitmap = Bitmap.createBitmap(BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length));
        return new BitmapDrawable(context.getResources(), bitmap);
    }
}