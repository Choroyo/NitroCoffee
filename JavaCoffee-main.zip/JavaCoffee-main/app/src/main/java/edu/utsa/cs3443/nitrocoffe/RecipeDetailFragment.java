package edu.utsa.cs3443.nitrocoffe;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import edu.utsa.cs3443.nitrocoffe.databinding.FragmentRecipeDetailBinding;
import edu.utsa.cs3443.nitrocoffe.model.RecipeModel;
import edu.utsa.cs3443.nitrocoffe.model.Recipes;
//
/**
 * RecipeDetailFragment is a class that extends Fragment.
 * It is used to display the details of a recipe in the application.
 *
 * @author Yael Reyes
 * @author Oscar Mallen

 */
public class RecipeDetailFragment extends Fragment {

    private FragmentRecipeDetailBinding binding;

    /**
     * Called to have the fragment instantiate its user interface view.
     *
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_recipe_detail, container, false);

        // Get the Recipes object from the Bundle
        Recipes recipe = (Recipes) getArguments().getParcelable("recipe");

        // Now you can use the recipe object to display the recipe details
        TextView recipeNameTextView = view.findViewById(R.id.recipeNameTextView);
        TextView coffeeGramsTextView = view.findViewById(R.id.coffeeGramsTextView);
        TextView waterGramsTextView = view.findViewById(R.id.waterGramsTextView);
        TextView milkGramsTextView = view.findViewById(R.id.milkGramsTextView);
        TextView otherIngredientsTextView = view.findViewById(R.id.otherIngredientsTextView);
        TextView instructionTextView = view.findViewById(R.id.instructionTextView);
        ImageView recipeImageView = view.findViewById(R.id.recipeImageView);

        recipeNameTextView.setText(recipe.getRecipeName());
        coffeeGramsTextView.setText("Coffee Grams: " + recipe.getCoffeeGrams());
        waterGramsTextView.setText("Water Grams: " + recipe.getWaterGrams());
        milkGramsTextView.setText("Milk Grams: " + recipe.getMilkGrams());
        otherIngredientsTextView.setText("Other Ingredients: " + String.join(", ", recipe.getOtherIngredients()));
        instructionTextView.setText(recipe.getRecipeDescription());
        recipeImageView.setImageResource(recipe.getRecipeImageResId());

        return view;
    }

}
