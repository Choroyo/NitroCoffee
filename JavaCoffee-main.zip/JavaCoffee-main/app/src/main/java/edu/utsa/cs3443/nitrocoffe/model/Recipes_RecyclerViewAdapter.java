package edu.utsa.cs3443.nitrocoffe.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import edu.utsa.cs3443.nitrocoffe.R;

/**
 * Recipes_RecyclerViewAdapter is a class that extends RecyclerView.Adapter.
 * It is used to bind the data to the RecyclerView and handle the data collection and bind it to the views within the RecyclerView.
 *
 * @author Yael Reyes
 * @author Oscar Mallen

 */
public class Recipes_RecyclerViewAdapter extends RecyclerView.Adapter<Recipes_RecyclerViewAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<Recipes> recipes;
    private OnItemClickListener listener;

    /**
     * Constructor for Recipes_RecyclerViewAdapter.
     *
     * @param context the context in which the adapter is being used.
     * @param recipes the list of recipe models to be displayed.
     */
    public Recipes_RecyclerViewAdapter(Context context, ArrayList<Recipes> recipes, OnItemClickListener listener) {
        this.context = context;
        this.recipes = recipes;
        this.listener = listener;
    }

    /**
     * Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type to represent an item.
     *
     * @param parent The ViewGroup into which the new View will be added after it is bound to an adapter position.
     * @param viewType The view type of the new View.
     * @return A new ViewHolder that holds a View of the given view type.
     */
    @NonNull
    @Override
    public Recipes_RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_view_row, parent, false);
        return new Recipes_RecyclerViewAdapter.MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Recipes recipeModel = recipes.get(position);

        // Set data to views
        holder.textViewName.setText(recipeModel.getRecipeName());
        holder.imageView.setImageResource(recipeModel.getRecipeImageResId());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(recipeModel);
            }
        });
    }

    public interface OnItemClickListener {
        void onItemClick(Recipes recipeModel);
    }
    /**
     * Returns the total number of items in the data set held by the adapter.
     *
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return recipes.size();
    }

    /**
     * A simple ViewHolder that can reference the Views in each item of the RecyclerView.
     */
    public static class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textViewName;

        /**
         * Constructor for MyViewHolder.
         *
         * @param itemView The View that you inflate in onCreateViewHolder().
         */
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textViewName = itemView.findViewById(R.id.textView5);
        }
    }


}