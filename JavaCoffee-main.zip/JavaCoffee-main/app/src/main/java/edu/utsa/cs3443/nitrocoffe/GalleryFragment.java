package edu.utsa.cs3443.nitrocoffe;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import edu.utsa.cs3443.nitrocoffe.databinding.FragmentGalleryBinding;
import edu.utsa.cs3443.nitrocoffe.model.InfoManager;
import edu.utsa.cs3443.nitrocoffe.model.User;

/**
 * GalleryFragment is a class that extends Fragment.
 * It is used to display a gallery of images in the application.
 *
 * @author Yael Reyes
 * @author Oscar Mallen
 */
public class GalleryFragment extends Fragment {
    private FragmentGalleryBinding binding;
    private  InfoManager manager;

    private User currentUser;
    private String currentUsername;
    private ArrayList<User> users;
    /**
     * Called to have the fragment instantiate its user interface view.
     *
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @SuppressLint("ResourceType")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentGalleryBinding.inflate(inflater, container,
                false);
        manager = new InfoManager(requireActivity());
        currentUsername = ((MainActivity)requireActivity()).getUsername();
        try {
            users = InfoManager.loadUsers(requireActivity());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        currentUser = manager.findUserByUsername(users,currentUsername);

        ImageView[] imageFrames = new ImageView[9];
        imageFrames[0] = binding.picture0;
        imageFrames[1] = binding.picture1;
        imageFrames[2] = binding.picture2;
        imageFrames[3] = binding.picture3;
        imageFrames[4] = binding.picture4;
        imageFrames[5] = binding.picture5;
        imageFrames[6] = binding.picture6;
        imageFrames[7] = binding.picture7;
        imageFrames[8] = binding.picture8;
        // Set click listeners for each recipe
        for (int i = 0; i < imageFrames.length && i < 9; i++) {
            int finalI = i;
            imageFrames[i].setOnClickListener(v -> {
                Drawable drawable = imageFrames[finalI].getDrawable();
                ((MainActivity)requireActivity()).setUserProfile(drawable);
                String pictureString = InfoManager.serializeDrawable(requireActivity(),drawable);
                Navigation.findNavController(binding.getRoot()).navigate(R.id.profile_fragment);
                try {
                    InfoManager.updateUserInFilePicture(requireActivity(),currentUser, users,pictureString);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        }
        return  binding.getRoot();
    }



}

