/** package edu.utsa.cs3443.nitrocoffe;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import java.io.IOException;

import edu.utsa.cs3443.nitrocoffe.databinding.FragmentAddRecipeBinding;
import edu.utsa.cs3443.nitrocoffe.model.InfoManager;
import edu.utsa.cs3443.nitrocoffe.model.User;

public class AddRecipeFragment extends Fragment {
    private FragmentAddRecipeBinding binding;
    private EditText nameRecipeEditText;
    private EditText waterGramsEditText;
    private EditText coffeGramsEditText;
    private EditText milkGramsEditText;
    private EditText otherIngredientsEditText;
    private EditText instructions;
    private ImageButton imageButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAddRecipeBinding.inflate(inflater,container,false);
        nameRecipeEditText = binding.recipeName;
        coffeGramsEditText = binding.enterCoffe;
        milkGramsEditText = binding.enterMilk;
        waterGramsEditText = binding.enterWater;


        return binding.getRoot();
    }


}
*/