package edu.utsa.cs3443.nitrocoffe.model;

import java.util.ArrayList;
//
/**
 * User is a class that represents a user with various attributes such as username, realName, password, bio, picture, recipes, and posts.
 * It provides getter and setter methods for each attribute.
 *
 * @author Yael Reyes
 * @author Oscar Mallen
 * @author Bryan Chora
 * @author Boston Jones
 */
public class User {
    private String username;
    private String realName;
    private String password;
    private String bio;
    private String picture;
    private ArrayList<Recipes> recipes;
    //private ArrayList<Social> posts;

    /**
     * Constructor for User.
     *
     * @param username the username of the user.
     * @param password the password of the user.
     * @param realName the real name of the user.
     * @param bio the bio of the user.
     * @param recipes the list of recipes of the user.
     * @param posts the list of posts of the user.
     */
    public User(String username, String password, String realName, String bio, ArrayList<Recipes> recipes) {
        this.username = username;
        this.realName = realName;
        this.password = password;
        this.bio = bio;
        this.recipes = new ArrayList<>();
        //this.posts = new ArrayList<>();
    }

    /**
     * Constructor for User.
     *
     * @param username the username of the user.
     * @param password the password of the user.
     * @param realName the real name of the user.
     * @param bio the bio of the user.
     */
    public User(String username, String password, String realName, String bio) {
        this.username = username;
        this.realName = realName;
        this.password = password;
        this.bio = bio;
        this.recipes = new ArrayList<Recipes>();
       // this.posts = new ArrayList<Social>();
    }

    /**
     * Constructor for User.
     *
     * @param username the username of the user.
     * @param password the password of the user.
     * @param realName the real name of the user.
     * @param bio the bio of the user.
     * @param picture the picture of the user.
     */
    public User(String username, String password, String realName, String bio,String picture) {
        this.username = username;
        this.realName = realName;
        this.password = password;
        this.picture = picture;
        this.bio = bio;
        this.recipes = new ArrayList<Recipes>();

    }

    /**
     * Gets the user's picture.
     *
     * @return the user's picture.
     */
    public String getPicture() {
        return picture;
    }

    /**
     * Sets the user's picture.
     *
     * @param picture the new user's picture.
     */
    public void setPicture(String picture) {
        this.picture = picture;
    }

    /**
     * Sets the user's username.
     *
     * @param username the new user's username.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the user's username.
     *
     * @return the user's username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Gets the user's real name.
     *
     * @return the user's real name.
     */
    public String getRealName() {
        return realName;
    }

    /**
     * Gets the user's password.
     *
     * @return the user's password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the user's password.
     *
     * @param password the new user's password.
     */
    public void setPassword(String password){
        this.password = password;
    }

    /**
     * Gets the user's list of recipes.
     *
     * @return the user's list of recipes.
     */
    public ArrayList<Recipes> getRecipes() {
        return recipes;
    }

    /**
     * Sets the user's list of recipes.
     *
     * @param recipes the new user's list of recipes.
     */
    public void setRecipes(ArrayList<Recipes> recipes) {
        this.recipes = recipes;
    }

    /**
     * Gets the user's list of posts.
     *
     * @return the user's list of posts.
     */


    /**
     * Sets the user's list of posts.
     *
     * @param posts the new user's list of posts.


    /**
     * Sets the user's real name.
     *
     * @param realName the new user's real name.
     */
    public void setRealName(String realName) {
        this.realName = realName;
    }

    /**
     * Gets the user's bio.
     *
     * @return the user's bio.
     */
    public String getBio() {
        return bio;
    }

    /**
     * Sets the user's bio.
     *
     * @param bio the new user's bio.
     */
    public void setBio(String bio) {
        this.bio = bio;
    }
}