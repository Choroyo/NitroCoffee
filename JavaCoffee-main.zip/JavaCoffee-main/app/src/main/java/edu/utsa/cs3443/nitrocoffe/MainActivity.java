package edu.utsa.cs3443.nitrocoffe;

import android.graphics.drawable.Drawable;
import android.media.RouteListingPreference;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.compose.ui.platform.ValueElementSequence;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavGraph;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import edu.utsa.cs3443.nitrocoffe.databinding.ActivityMainBinding;

/**
 * MainActivity is the main activity class that extends AppCompatActivity.
 * It handles the navigation and user interactions within the application.
 *
 *
 *
 * final TEAM
 * @author Yael Reyes
 * @author Oscar Mallen

 */
public class MainActivity extends AppCompatActivity {

    private String username;
    private NavController navController;
    ActivityMainBinding binding;
    private Drawable userProfile;


    /**
     * Called when the activity is starting.
     * This is where most initialization should go.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being shut down then this Bundle contains the data it most recently supplied in onSaveInstanceState(Bundle).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.topAppBar);
        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.frag_container_view);
        assert navHostFragment != null;
        navController = navHostFragment.getNavController();
        NavGraph navGraph = navController.getNavInflater().inflate(R.navigation.nav_graph);
        navController.setGraph(navGraph);
        AppBarConfiguration appBarConfiguration =
                new AppBarConfiguration.Builder(
                        R.id.login_fragment,
                        R.id.profile_fragment,
                        R.id.social_fragment,
                        R.id.recipe_fragment,
                        R.id.marketplace_fragment
                ).build();
        NavigationUI.setupWithNavController(findViewById(R.id.topAppBar), navController, appBarConfiguration);
//
       navController.addOnDestinationChangedListener((navController1, navDestination, bundle) -> {

           if(navDestination.getId() == R.id.recipe_fragment){
               binding.bottomNavigation.setVisibility(View.VISIBLE);
           }else if(navDestination.getId() == R.id.social_fragment){
               binding.bottomNavigation.setVisibility(View.VISIBLE);
           }else if(navDestination.getId() == R.id.profile_fragment) {
               binding.bottomNavigation.setVisibility(View.VISIBLE);
           }else if(navDestination.getId() == R.id.marketplace_fragment){
               binding.bottomNavigation.setVisibility(View.VISIBLE);
           }else{
               binding.bottomNavigation.setVisibility(View.GONE);
           }
       });
        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.marketplace) {
                navController.navigate(R.id.marketplace_fragment);
            } else if (itemId == R.id.recipe) {
                navController.navigate(R.id.recipe_fragment);;
            } else if (itemId == R.id.profile) {
                navController.navigate(R.id.profile_fragment);
            }
            return true;
        });
    }

    /**
     * Gets the username of the user.
     *
     * @return the username of the user.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username of the user.
     *
     * @param username the new username of the user.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the user's profile picture.
     *
     * @return the user's profile picture.
     */
    public Drawable getUserProfile(){
        return userProfile;
    }

    /**
     * Sets the user's profile picture.
     *
     * @param userProfile the new user's profile picture.
     */
    public void setUserProfile(Drawable userProfile){
        this.userProfile = userProfile;
    }
}
