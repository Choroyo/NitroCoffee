package edu.utsa.cs3443.nitrocoffe;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import edu.utsa.cs3443.nitrocoffe.model.InfoManager;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import java.io.IOException;
import edu.utsa.cs3443.nitrocoffe.databinding.FragmentRegisterBinding;
import edu.utsa.cs3443.nitrocoffe.model.User;

/**
 * RegisterFragment is a class that extends Fragment.
 * It is used to handle the registration functionality of the application.
 *
 * @author Yael Reyes
 * @author Oscar Mallen

 */
public class RegisterFragment extends Fragment {

    private FragmentRegisterBinding binding;
    private EditText nameEditText;
    private EditText passwordEditText;
    private EditText confirmPasswordEditText;
    private EditText realNameEditText; //
    private Button registerButton;

    /**
     * Called to have the fragment instantiate its user interface view.
     *
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentRegisterBinding.inflate(inflater,container,false);
        nameEditText = binding.usernameInput;
        passwordEditText = binding.passwordInput;
        confirmPasswordEditText = binding.passwordConfirmInput;
        realNameEditText = binding.realNameInput; // Add this line
        registerButton = binding.registerButton;

        registerButton.setOnClickListener(v -> {
            String username = nameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            String confirmPassword = confirmPasswordEditText.getText().toString().trim();
            String realName = realNameEditText.getText().toString().trim(); // Add this line
//
            if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || realName.isEmpty()) {
                Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(getContext(), "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.length() <= 4){
                Toast.makeText(getContext(),"Password is to short", Toast.LENGTH_SHORT).show();
                return;
            }
            User newUser = new User(username,password,realName, "Empty"); // Use the real name

            try {
                InfoManager.addUserInFile(requireActivity(), newUser); // Save the new user in the userInDevice.csv file
                Toast.makeText(getContext(), "User registered successfully", Toast.LENGTH_SHORT).show();
                Navigation.findNavController(binding.getRoot()).navigate(R.id.profile_fragment);
            } catch (IOException e) {
                Toast.makeText(requireActivity(), "Fail to register", Toast.LENGTH_SHORT).show();
            }
            Toast.makeText(getContext(), "User registered successfully", Toast.LENGTH_SHORT).show();
            ((MainActivity)requireActivity()).setUsername(nameEditText.getText().toString());
            Navigation.findNavController(binding.getRoot()).navigate(R.id.recipe_fragment);
        });

        return binding.getRoot();
    }
}