package edu.utsa.cs3443.nitrocoffe.model;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Keep;

/**
 * RecipeModel is a class that represents a recipe model with a name and an image.
 * It provides methods to get the name and the image of the recipe.
 *
 * @author Yael Reyes
 * @author Oscar Mallen
 */
@Keep
public class RecipeModel implements Parcelable {

    private String recipeName;
    private int image;

    /**
     * Constructor for RecipeModel.
     *
     * @param recipeName the name of the recipe.
     * @param image the image resource ID of the recipe.
     */
    public RecipeModel(String recipeName, int image) {
        this.recipeName = recipeName;
        this.image = image;
    }

    /**
     * Constructor for RecipeModel that creates a new instance from a Parcel.
     *
     * @param in the Parcel to read the object's data from.
     */
    protected RecipeModel(Parcel in) {
        recipeName = in.readString();
        image = in.readInt();
    }

    /**
     * Writes the object's data to the given Parcel.
     *
     * @param dest the Parcel to write the object's data to.
     * @param flags additional flags about how the object should be written.
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(recipeName);
        dest.writeInt(image);
    }

    /**
     * Describes the kinds of special objects contained in this Parcelable's
     * marshalled representation.
     *
     * @return a bitmask indicating the set of special object types marshalled
     * by the Parcelable.
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * A public CREATOR field that generates instances of your Parcelable class from a Parcel.
     */
    public static final Creator<RecipeModel> CREATOR = new Creator<RecipeModel>() {
        @Override
        public RecipeModel createFromParcel(Parcel in) {
            return new RecipeModel(in);
        }

        @Override
        public RecipeModel[] newArray(int size) {
            return new RecipeModel[size];
        }
    };

    /**
     * Gets the name of the recipe.
     *
     * @return the name of the recipe.
     */
    public String getRecipeName() {
        return recipeName;
    }

    /**
     * Gets the image resource ID of the recipe.
     *
     * @return the image resource ID of the recipe.
     */
    public int getImage() {
        return image;
    }
}