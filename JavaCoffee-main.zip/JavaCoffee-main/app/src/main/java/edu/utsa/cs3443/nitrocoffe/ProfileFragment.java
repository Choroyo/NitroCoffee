package edu.utsa.cs3443.nitrocoffe;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import java.io.IOException;
import java.util.ArrayList;

import edu.utsa.cs3443.nitrocoffe.databinding.FragmentProfileBinding;
import edu.utsa.cs3443.nitrocoffe.model.InfoManager;
import edu.utsa.cs3443.nitrocoffe.model.User;

/**
 * ProfileFragment is a class that extends Fragment.
 * It is used to handle the profile functionality of the application.
 *
 * @author Yael Reyes
 * @author Oscar Mallen

 */
public class ProfileFragment extends Fragment {

    private String checkSavedInstanceState;
    private FragmentProfileBinding binding;
    private Button logOutButton;
    private TextView displayNameTextView;
    private EditText bioEditText;
    private TextView bioTextView;
    private ImageView profilePicture;
    private Button editBioButton;
    private String currentUsername;
    private User currentUser;
    private TextView usernameTextView;
    private  InfoManager manager;
    private ArrayList<User> users;
    private Button save;

    private Drawable picture;

    /**
     * Called to have the fragment instantiate its user interface view.
     *
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater,container,false);
        manager = new InfoManager(requireActivity());
        logOutButton = binding.logOut;
        displayNameTextView = binding.name;
        bioTextView = binding.textBio;
        bioEditText = binding.editTextBio;
        save = binding.saveButton;
        profilePicture = binding.profilePicture;
        editBioButton = binding.editBio;
        currentUsername = ((MainActivity)requireActivity()).getUsername();
        try {
            users = InfoManager.loadUsers(requireActivity());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        currentUser = manager.findUserByUsername(users,currentUsername);
        profilePicture.setOnClickListener(v ->{
            Navigation.findNavController(binding.getRoot()).navigate(R.id.galleryFragment);
        });
        if (!currentUser.getPicture().equals("null")){
            profilePicture.setImageDrawable(((MainActivity)requireActivity()).getUserProfile());
        }
        displayNameTextView.setText(currentUser.getUsername());
        bioTextView.setText(currentUser.getBio());

        logOutButton.setOnClickListener(v->{
            Navigation.findNavController(binding.getRoot()).navigate(R.id.login_fragment);
        });
        editBioButton.setOnClickListener(v->{
            if(bioEditText.getVisibility()== View.GONE){
                bioEditText.setText(bioTextView.getText());
                bioTextView.setVisibility(View.GONE);
                bioEditText.setVisibility(View.VISIBLE);
                editBioButton.setVisibility(View.GONE);
                save.setVisibility(View.VISIBLE);
            }
        });
        save.setOnClickListener(v -> {
            bioTextView.setText(bioEditText.getText());
            bioTextView.setVisibility(View.VISIBLE);
            bioEditText.setVisibility(View.GONE);
            save.setVisibility(View.GONE);
            currentUser.setBio(bioEditText.getText().toString().trim());
            editBioButton.setVisibility(View.VISIBLE);
            try {
                InfoManager.updateUserInFile(requireActivity(),currentUser, users);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return binding.getRoot();
    }

}