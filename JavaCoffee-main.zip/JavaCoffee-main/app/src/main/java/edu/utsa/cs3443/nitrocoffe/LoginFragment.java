package edu.utsa.cs3443.nitrocoffe;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;

import edu.utsa.cs3443.nitrocoffe.databinding.FragmentLoginBinding;
import edu.utsa.cs3443.nitrocoffe.model.InfoManager;
import edu.utsa.cs3443.nitrocoffe.model.User;

/**
 * LoginFragment is a class that extends Fragment.
 * It is used to handle the login functionality of the application.
 *
 * @author Yael Reyes
 * @author Oscar Mallen
 */
public class LoginFragment extends Fragment {
    private FragmentLoginBinding binding;
    private EditText nameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;
    private ArrayList<User> users;
    private InfoManager manager;

    /**
     * Called to have the fragment instantiate its user interface view.
     *
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentLoginBinding.inflate(inflater, container, false);
        manager = new InfoManager(requireActivity());
        nameEditText = binding.usernameInput;
        passwordEditText = binding.passwordInput;
        loginButton = binding.loginButton;
        registerButton = binding.registerButton;

        // Initialize user data file
        try {
            InfoManager.initFileUser(requireActivity());
        } catch (IOException e) {
            Toast.makeText(requireActivity(), "Failed to initialize user data file.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        // Load users from the data file
        try {
            users = manager.loadUsers(requireActivity());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // Set click listener for the login button
        loginButton.setOnClickListener(v -> {
            if (manager.isValidLogin(nameEditText.getText().toString(), passwordEditText.getText().toString(), users)) {
                Toast.makeText(getContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                ((MainActivity)requireActivity()).setUsername(nameEditText.getText().toString());
                Navigation.findNavController(binding.getRoot()).navigate(R.id.recipe_fragment);
            } else {
                Toast.makeText(getContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Set click listener for the register button
        registerButton.setOnClickListener(v -> {
            Navigation.findNavController(binding.getRoot()).navigate(R.id.register_fragment);
        });

        return binding.getRoot();
    }
}