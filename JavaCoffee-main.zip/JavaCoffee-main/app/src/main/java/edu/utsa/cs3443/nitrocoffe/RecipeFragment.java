package edu.utsa.cs3443.nitrocoffe;
import androidx.fragment.app.Fragment;

import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import edu.utsa.cs3443.nitrocoffe.databinding.FragmentRecipeBinding;
import edu.utsa.cs3443.nitrocoffe.model.InfoManager;
import edu.utsa.cs3443.nitrocoffe.model.RecipeModel;

import edu.utsa.cs3443.nitrocoffe.model.Recipes;
import edu.utsa.cs3443.nitrocoffe.model.Recipes_RecyclerViewAdapter;



/**
 * RecipeFragment is a class that extends Fragment.
 * It is used to display a list of recipes in the application.
 *
 * @author Yael Reyes
 * @author Oscar Mallen

 */
public class RecipeFragment extends Fragment implements Recipes_RecyclerViewAdapter.OnItemClickListener {

    private FragmentRecipeBinding binding;

    private  InfoManager manager;

    private ArrayList<Recipes> recipes;
    ArrayList<RecipeModel> RecipeModels = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentRecipeBinding.inflate(inflater,container,false);
        manager = new InfoManager(requireActivity());
        try {
            InfoManager.initFileRecipes(requireActivity());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            recipes = manager.loadRecipes(requireActivity());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        View view = inflater.inflate(R.layout.fragment_recipe, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.rRecyclerView);

        Log.i("RecipeFragment", "Recipes: " + recipes);

        Recipes_RecyclerViewAdapter adapter = new Recipes_RecyclerViewAdapter(getContext(), recipes, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        return view;
    }

    @Override
    public void onItemClick(Recipes recipeModel) {
        // Perform the action when a recipe is clicked
        // For example, navigate to the RecipeDetailFragment
        Bundle bundle = new Bundle();
        bundle.putParcelable("recipe", recipeModel);
        Navigation.findNavController(getView()).navigate(R.id.action_recipe_fragment_to_recipe_detailFragment, bundle);
    }
}